package com.myra.maya;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.net.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    private TextView status, transcript, reply;
    private EditText apiKey, message;
    private TextToSpeech tts;
    private static final int SPEECH_REQUEST = 77;
    private final int bg = Color.rgb(12, 10, 24);
    private final int accent = Color.rgb(190, 95, 255);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        tts = new TextToSpeech(this, result -> { if(result == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("en","US")); });
        buildUI();
    }
    private TextView text(String s, int size, int color) {
        TextView v=new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(color); return v;
    }
    private void buildUI() {
        ScrollView scroll=new ScrollView(this);
        LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(24,34,24,24); root.setBackgroundColor(bg);
        scroll.addView(root);
        TextView title=text("M A Y A",32,Color.WHITE); title.setTypeface(null,Typeface.BOLD); title.setGravity(Gravity.CENTER); root.addView(title);
        TextView sub=text("AI VOICE COMPANION  •  ANDROID",11,accent); sub.setGravity(Gravity.CENTER); root.addView(sub);
        TextView orb=text("✦",76,accent); orb.setGravity(Gravity.CENTER); orb.setPadding(0,24,0,16); root.addView(orb);
        status=text("SYSTEM ONLINE",14,Color.GREEN); status.setGravity(Gravity.CENTER); root.addView(status);
        transcript=text("Tap the microphone and say “Maya” or speak a command.",16,Color.WHITE); transcript.setPadding(0,24,0,12); root.addView(transcript);
        Button listen=button("🎙  SPEAK TO MAYA"); root.addView(listen); listen.setOnClickListener(v->startListening());
        message=new EditText(this); message.setSingleLine(false); message.setHint("Type a message…"); message.setHintTextColor(0xff888888); message.setTextColor(Color.WHITE); message.setPadding(12,12,12,12); root.addView(message);
        Button send=button("SEND MESSAGE"); root.addView(send); send.setOnClickListener(v->{String q=message.getText().toString().trim(); if(!q.isEmpty()){message.setText(""); process(q);}});
        reply=text("Maya’s response will appear here.",15,0xffdddddd); reply.setPadding(0,20,0,20); root.addView(reply);
        TextView keyLabel=text("GEMINI API KEY (optional)",12,accent); root.addView(keyLabel);
        apiKey=new EditText(this); apiKey.setSingleLine(true); apiKey.setHint("Paste your Gemini API key"); apiKey.setHintTextColor(0xff888888); apiKey.setTextColor(Color.WHITE); apiKey.setInputType( android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD); root.addView(apiKey);
        apiKey.setText(getPreferences(0).getString("gemini_key",""));
        Button save=button("SAVE API KEY"); root.addView(save); save.setOnClickListener(v->{getPreferences(0).edit().putString("gemini_key",apiKey.getText().toString().trim()).apply(); say("API key saved on this device.");});
        TextView foot=text("Maya AI 1.0 • Internet is needed for Gemini replies.",11,0xff888888); foot.setPadding(0,28,0,8); root.addView(foot);
        setContentView(scroll);
    }
    private Button button(String label) {
        Button b=new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff542080)); return b;
    }
    private void startListening() {
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Speak to Maya");
        try { startActivityForResult(i,SPEECH_REQUEST); } catch(Exception e) { status.setText("Speech recognition unavailable"); }
    }
    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if(request==SPEECH_REQUEST && result==RESULT_OK && data!=null) {
            ArrayList<String> matches=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if(matches!=null&&!matches.isEmpty()) process(matches.get(0));
        }
    }
    private void process(String q) {
        transcript.setText("You: "+q); String s=q.toLowerCase(Locale.ROOT);
        if(s.contains("open youtube") || s.contains("ইউটিউব")) { open("https://www.youtube.com"); return; }
        if(s.contains("open google") || s.contains("গুগল")) { open("https://www.google.com"); return; }
        if(s.contains("open facebook") || s.contains("ফেসবুক")) { open("https://www.facebook.com"); return; }
        if(s.startsWith("search ") || s.contains("search google") || s.contains("খুঁজে")) {
            try { String query=URLEncoder.encode(q,"UTF-8"); open("https://www.google.com/search?q="+query); } catch(Exception ignored) {} return;
        }
        if(s.contains("time") || s.contains("সময়")) { say("The time is "+new java.text.SimpleDateFormat("h:mm a",Locale.getDefault()).format(new Date())); return; }
        String key=getPreferences(0).getString("gemini_key","");
        if(key.isEmpty()) { say("Please add your Gemini API key in settings below to enable AI chat."); return; }
        askGemini(q,key);
    }
    private void open(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url))); say("Opening it now."); }
        catch(Exception e){ say("I could not open that link."); }
    }
    private void askGemini(String q,String key) {
        status.setText("THINKING…");
        new Thread(()->{
            String answer="Sorry, I could not connect to the AI service.";
            HttpURLConnection c=null;
            try {
                URL u=new URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key="+URLEncoder.encode(key,"UTF-8"));
                c=(HttpURLConnection)u.openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(20000); c.setReadTimeout(30000); c.setDoOutput(true); c.setRequestProperty("Content-Type","application/json");
                JSONObject part=new JSONObject().put("text","You are Maya, a helpful bilingual Bangla-English Android voice assistant. Reply naturally and concisely. User: "+q);
                JSONObject body=new JSONObject().put("contents",new JSONArray().put(new JSONObject().put("parts",new JSONArray().put(part))));
                try(OutputStream os=c.getOutputStream()){os.write(body.toString().getBytes("UTF-8"));}
                InputStream is=(c.getResponseCode()<400)?c.getInputStream():c.getErrorStream();
                ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] buf=new byte[4096]; int n; while((n=is.read(buf))>0)out.write(buf,0,n);
                JSONObject json=new JSONObject(out.toString("UTF-8"));
                answer=json.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text");
            } catch(Exception e) { answer="AI connection failed. Check your API key and internet connection."; }
            finally { if(c!=null)c.disconnect(); }
            final String result=answer;
            runOnUiThread(()->{status.setText("SYSTEM ONLINE"); reply.setText(result); speak(result);});
        }).start();
    }
    private void say(String s) { reply.setText(s); speak(s); }
    private void speak(String s) { if(tts!=null) tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"maya_reply"); }
    @Override protected void onDestroy(){ if(tts!=null){tts.stop();tts.shutdown();} super.onDestroy(); }
}