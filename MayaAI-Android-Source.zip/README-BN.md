# Maya AI Android — Source Project

এই প্রজেক্টটি আপলোড করা Maya AI 1.2 macOS/Python অ্যাপের Android-এ নতুন করে তৈরি করা সংস্করণ। মূল Python কোড সরাসরি APK-তে রূপান্তরযোগ্য ছিল না; তাই Android Native Java অ্যাপ তৈরি করা হয়েছে।

## ফিচার
- বাংলা Speech Recognition (Android-এর speech service ব্যবহার করে)
- Text-to-Speech উত্তর
- Gemini API দিয়ে AI chat (নিজের API key লাগবে)
- YouTube, Google, Facebook ওপেন
- Google Search কমান্ড
- Dark purple Maya UI
- API key ডিভাইসে Preferences-এ সংরক্ষণ

## APK বানানোর নিয়ম (Android ফোনেও)
1. AndroidIDE বা Android Studio-তে এই ফোল্ডারটি Open করুন।
2. Gradle sync শেষ হতে দিন। JDK 17 এবং Android SDK Platform 35 লাগবে।
3. Build > Build APK(s) নির্বাচন করুন।
4. APK সাধারণত `app/build/outputs/apk/debug/app-debug.apk`-এ তৈরি হবে।
5. ফোনে ইনস্টল করতে Unknown app install অনুমতি দিন।

## API Key
Google AI Studio থেকে Gemini API key তৈরি করে অ্যাপে `GEMINI API KEY` ঘরে দিন। API key গোপন রাখুন; কাউকে পাঠাবেন না। Production অ্যাপে key সরাসরি client-এ রাখা নিরাপদ নয়—নিজস্ব backend ব্যবহার করা উত্তম।

## সীমাবদ্ধতা
- এটি সবসময় ব্যাকগ্রাউন্ডে wake-word শুনতে থাকে না। Android-এ স্থায়ী “Hey Maya” listening-এর জন্য foreground service, notification, battery-optimization handling এবং অতিরিক্ত permission দরকার।
- macOS-এর VS Code/Safari/Chrome control, Finder folder search ও screenshot feature Android-এ প্রযোজ্য নয়; তাই Android intent-based action দেওয়া হয়েছে।
- Speech recognition availability ডিভাইসের Google speech service ও internet-এর ওপর নির্ভর করতে পারে।
